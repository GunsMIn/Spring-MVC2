package hello.form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormApplicationTests {

	@Test
	void contextLoads() {
	}

}
